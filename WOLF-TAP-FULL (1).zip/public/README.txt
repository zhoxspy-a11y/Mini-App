Wolf character asset supplied by the project owner and bundled locally as /wolf.png.
