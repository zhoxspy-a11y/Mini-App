# WOLF TAP — Full Telegram Mini App

This package is the real application foundation, not a fake balance-only demo.

Included:
- Telegram Mini App initData authentication
- Supabase/PostgreSQL persistence
- Server-authoritative tap + energy logic
- Levels and boosts
- Referral tracking from `startapp=ref_USERID`
- Dynamic tasks
- Telegram channel membership verification through Bot API
- Task rewards with one-time transaction protection
- YouTube/external-link task workflow with honest verification states
- Real admin authentication based on Telegram user ID
- Admin task CRUD, users, settings, announcements and withdrawal-free wallet management
- Separate Game Coin ledger
- Wolf asset bundled locally
- No ads and no withdrawal system
- Responsive mobile-first UI
- SVG icon system via lucide-react
- No emoji icons

## Required Vercel environment variables

Set these in Vercel Project Settings → Environment Variables:

SUPABASE_URL
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
SUPABASE_SECRET_KEY
TELEGRAM_BOT_TOKEN
TELEGRAM_BOT_USERNAME
ADMIN_TELEGRAM_ID
NEXT_PUBLIC_APP_URL

The Supabase publishable key is safe for browser use. Never expose `SUPABASE_SECRET_KEY` or `TELEGRAM_BOT_TOKEN` in client code.

## Supabase setup

Open the SQL file:
`supabase/schema.sql`

Paste the whole file into Supabase SQL Editor and run it once.

It creates:
- profiles
- balances
- tap_events
- referrals
- tasks
- task_claims
- boosts
- user_boosts
- transactions
- announcements
- app_settings
- admin_audit_logs

## Telegram setup

1. Create/configure the bot in BotFather.
2. Set the Mini App URL to the Vercel deployment URL.
3. The Mini App must be opened inside Telegram so `Telegram.WebApp.initData` exists.
4. For Telegram task verification, the bot must be an administrator of the target channel.
5. The channel task must store the channel username/ID in the task verification field.

This project intentionally does not fake Telegram membership verification.

## Important

No ads are included.
No bKash/USDT/TON withdrawal system is included.
Game Coins are an internal game/airdrop-style balance only.

For YouTube subscriptions and arbitrary external links, automatic proof is not available from a normal browser alone. The admin panel therefore supports a manual-review task mode rather than falsely marking a user complete.

## Local development

```bash
npm install
npm run dev
```

Use a real Telegram Mini App URL for authentication testing. A normal browser does not have valid Telegram WebApp initData.
