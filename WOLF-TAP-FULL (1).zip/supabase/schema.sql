create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint unique not null,
  username text,
  first_name text,
  last_name text,
  language_code text,
  photo_url text,
  referrer_telegram_id bigint,
  level integer not null default 1,
  energy integer not null default 1000,
  last_energy_at timestamptz not null default now(),
  suspended boolean not null default false,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table if not exists balances (
  profile_id uuid primary key references profiles(id) on delete cascade,
  coins bigint not null default 0,
  lifetime_coins bigint not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists tap_events (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  tap_count integer not null,
  coin_amount bigint not null,
  energy_spent integer not null,
  client_nonce text not null,
  created_at timestamptz not null default now(),
  unique(profile_id, client_nonce)
);

create table if not exists referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_telegram_id bigint not null,
  referred_telegram_id bigint unique not null,
  reward bigint not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists tasks (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('telegram','youtube','link')),
  title text not null,
  description text,
  url text,
  verification_value text,
  reward bigint not null default 0,
  active boolean not null default true,
  require_manual_review boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists task_claims (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references tasks(id) on delete cascade,
  profile_id uuid not null references profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  reward bigint not null default 0,
  proof text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  unique(task_id, profile_id)
);

create table if not exists boosts (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  name text not null,
  description text,
  price bigint not null default 0,
  effect_value integer not null default 1,
  active boolean not null default true
);

create table if not exists user_boosts (
  profile_id uuid not null references profiles(id) on delete cascade,
  boost_id uuid not null references boosts(id) on delete cascade,
  level integer not null default 0,
  primary key(profile_id, boost_id)
);

create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  type text not null,
  amount bigint not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null,
  button_text text,
  button_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists app_settings (
  key text primary key,
  value jsonb not null
);

create table if not exists admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  admin_telegram_id bigint not null,
  action text not null,
  target text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists profiles_telegram_id_idx on profiles(telegram_id);
create index if not exists profiles_referrer_idx on profiles(referrer_telegram_id);
create index if not exists transactions_profile_idx on transactions(profile_id);
create index if not exists task_claims_profile_idx on task_claims(profile_id);
create index if not exists task_claims_task_idx on task_claims(task_id);

insert into app_settings(key,value) values
('tap_reward','1'),
('tap_energy_cost','1'),
('max_energy','1000'),
('energy_regen_per_second','1'),
('referral_reward','500'),
('new_user_bonus','0'),
('level_step','1000')
on conflict(key) do nothing;

insert into boosts(key,name,description,price,effect_value)
values
('multitap','Multitap','Increase Game Coins earned per tap.',1000,2),
('energy','Energy Core','Increase maximum energy by 100.',1500,100)
on conflict(key) do nothing;
