import { NextResponse } from "next/server";
import { adminDb } from "@/lib/supabase";
import { requireTelegram } from "@/lib/auth";

async function check(req){
  const {user}=requireTelegram(req);
  if(String(user.id)!==String(process.env.ADMIN_TELEGRAM_ID)) throw new Error("Admin access denied");
  return user;
}
export async function POST(req){
  try{
    const user=await check(req); const body=await req.json(); const db=adminDb();
    const clean={type:body.type,title:String(body.title||"").trim(),description:body.description||null,url:body.url||null,verification_value:body.verification_value||null,reward:Math.max(0,Number(body.reward||0)),active:Boolean(body.active??true),require_manual_review:Boolean(body.require_manual_review??false)};
    if(!clean.title)throw new Error("Task title required");
    const {data:task,error}=await db.from("tasks").insert(clean).select().single(); if(error)throw error;
    await db.from("admin_audit_logs").insert({admin_telegram_id:user.id,action:"task.create",target:task.id,metadata:clean});
    return NextResponse.json({task});
  }catch(e){return NextResponse.json({error:e.message},{status:400})}
}
