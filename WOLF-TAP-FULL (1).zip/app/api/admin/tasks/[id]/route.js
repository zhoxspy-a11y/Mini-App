import { NextResponse } from "next/server";
import { adminDb } from "@/lib/supabase";
import { requireTelegram } from "@/lib/auth";
export async function DELETE(req,{params}){
  try{
    const {user}=requireTelegram(req);
    if(String(user.id)!==String(process.env.ADMIN_TELEGRAM_ID))throw new Error("Admin access denied");
    const db=adminDb(); const {error}=await db.from("tasks").delete().eq("id",params.id); if(error)throw error;
    await db.from("admin_audit_logs").insert({admin_telegram_id:user.id,action:"task.delete",target:params.id});
    return NextResponse.json({ok:true});
  }catch(e){return NextResponse.json({error:e.message},{status:403})}
}
