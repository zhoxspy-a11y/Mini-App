import { NextResponse } from "next/server";
import { adminDb } from "@/lib/supabase";
import { requireTelegram } from "@/lib/auth";

async function admin(req){
  const {user}=requireTelegram(req);
  if(String(user.id)!==String(process.env.ADMIN_TELEGRAM_ID)) throw new Error("Admin access denied");
  return user;
}
export async function GET(req){
  try{
    await admin(req); const db=adminDb();
    const [{data:users},{data:tasks},{data:balances}]=await Promise.all([
      db.from("profiles").select("telegram_id,username,first_name,level").order("created_at",{ascending:false}).limit(50),
      db.from("tasks").select("*").order("sort_order").order("created_at",{ascending:false}),
      db.from("balances").select("coins")
    ]);
    return NextResponse.json({
      stats:{users:(users||[]).length,coins:(balances||[]).reduce((a,b)=>a+Number(b.coins||0),0)},
      users:(users||[]).map(u=>({...u,coins:0})),
      tasks:tasks||[]
    });
  }catch(e){return NextResponse.json({error:e.message},{status:403})}
}
