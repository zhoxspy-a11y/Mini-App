import { NextResponse } from "next/server";
import { adminDb } from "@/lib/supabase";
import { requireTelegram } from "@/lib/auth";
import { applyEnergy, levelForCoins, settingNumber } from "@/lib/game";

export async function GET(req){
  try{
    const {user}=requireTelegram(req);
    const db=adminDb();
    const {data:settings}=await db.from("app_settings").select("key,value");
    const s=Object.fromEntries((settings||[]).map(x=>[x.key,x.value]));
    const max=settingNumber(s,"max_energy",1000);
    const regen=settingNumber(s,"energy_regen_per_second",1);
    let {data:p}=await db.from("profiles").select("*").eq("telegram_id",user.id).maybeSingle();
    const isNew=!p;
    if(!p){
      let referrer=null;
      const raw=req.headers.get("x-telegram-start-param") || "";
      const match=raw.match(/^ref_(\d+)$/);
      if(match && Number(match[1])!==Number(user.id)) referrer=Number(match[1]);
      const {data:created,error}=await db.from("profiles").insert({
        telegram_id:user.id,username:user.username||null,first_name:user.first_name||null,last_name:user.last_name||null,
        language_code:user.language_code||null,photo_url:user.photo_url||null,referrer_telegram_id:referrer,
        energy:max
      }).select().single();
      if(error) throw error;
      p=created;
      await db.from("balances").insert({profile_id:p.id,coins:settingNumber(s,"new_user_bonus",0),lifetime_coins:settingNumber(s,"new_user_bonus",0)});
      if(referrer){
        const reward=settingNumber(s,"referral_reward",500);
        const {data:refProf}=await db.from("profiles").select("id").eq("telegram_id",referrer).maybeSingle();
        if(refProf){
          const {data:existing}=await db.from("referrals").select("id").eq("referred_telegram_id",user.id).maybeSingle();
          if(!existing){
            const {data:refBal}=await db.from("balances").select("coins,lifetime_coins").eq("profile_id",refProf.id).single();
            if(refBal) await db.from("balances").update({coins:refBal.coins+reward,lifetime_coins:refBal.lifetime_coins+reward,updated_at:new Date().toISOString()}).eq("profile_id",refProf.id);
            await db.from("referrals").insert({referrer_telegram_id:referrer,referred_telegram_id:user.id,reward});
          }
        }
      }
    }else{
      await db.from("profiles").update({username:user.username||null,first_name:user.first_name||null,last_name:user.last_name||null,last_seen_at:new Date().toISOString()}).eq("id",p.id);
    }
    const energy=applyEnergy(p,max,regen);
    if(energy.changed) await db.from("profiles").update({energy:energy.energy,last_energy_at:energy.now}).eq("id",p.id);
    const {data:b}=await db.from("balances").select("*").eq("profile_id",p.id).single();
    const coins=b?.coins||0;
    const step=settingNumber(s,"level_step",1000);
    const level=levelForCoins(coins,step);
    if(level!==p.level) await db.from("profiles").update({level}).eq("id",p.id);
    const {data:tasks}=await db.from("tasks").select("*").eq("active",true).order("sort_order").order("created_at",{ascending:false});
    const {data:claims}=await db.from("task_claims").select("task_id,status").eq("profile_id",p.id);
    const map=Object.fromEntries((claims||[]).map(c=>[c.task_id,c.status]));
    const {data:boosts}=await db.from("boosts").select("*").eq("active",true);
    return NextResponse.json({profile:{...p,level},coins,energy:energy.energy,maxEnergy:max,level,tasks:(tasks||[]).map(t=>({...t,claimStatus:map[t.id]||null})),boosts:boosts||[]});
  }catch(e){return NextResponse.json({error:e.message},{status:401})}
}
