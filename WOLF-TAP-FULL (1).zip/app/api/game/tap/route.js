import { NextResponse } from "next/server";
import { adminDb } from "@/lib/supabase";
import { requireTelegram } from "@/lib/auth";
import { applyEnergy, settingNumber } from "@/lib/game";

export async function POST(req){
  try{
    const {user}=requireTelegram(req);
    const body=await req.json();
    const tapCount=Math.max(1,Math.min(10,Number(body.tapCount||1)));
    const nonce=String(body.clientNonce||"");
    if(!nonce) throw new Error("Missing request nonce");
    const db=adminDb();
    const {data:sRows}=await db.from("app_settings").select("key,value");
    const s=Object.fromEntries((sRows||[]).map(x=>[x.key,x.value]));
    const reward=settingNumber(s,"tap_reward",1);
    const cost=settingNumber(s,"tap_energy_cost",1);
    const max=settingNumber(s,"max_energy",1000);
    const regen=settingNumber(s,"energy_regen_per_second",1);
    const {data:p}=await db.from("profiles").select("*").eq("telegram_id",user.id).single();
    if(!p || p.suspended) throw new Error("Account unavailable");
    const e=applyEnergy(p,max,regen);
    if(e.energy < tapCount*cost) throw new Error("Not enough energy");
    const {data:existing}=await db.from("tap_events").select("id").eq("profile_id",p.id).eq("client_nonce",nonce).maybeSingle();
    if(existing) throw new Error("Duplicate tap request");
    const amount=tapCount*reward;
    const {data:b}=await db.from("balances").select("coins,lifetime_coins").eq("profile_id",p.id).single();
    const newEnergy=e.energy-tapCount*cost;
    await db.from("balances").update({coins:b.coins+amount,lifetime_coins:b.lifetime_coins+amount,updated_at:new Date().toISOString()}).eq("profile_id",p.id);
    await db.from("profiles").update({energy:newEnergy,last_energy_at:e.now}).eq("id",p.id);
    await db.from("tap_events").insert({profile_id:p.id,tap_count:tapCount,coin_amount:amount,energy_spent:tapCount*cost,client_nonce:nonce});
    await db.from("transactions").insert({profile_id:p.id,type:"tap",amount,metadata:{tapCount}});
    return NextResponse.json({coins:b.coins+amount,energy:newEnergy,maxEnergy:max,level:Math.floor((b.coins+amount)/settingNumber(s,"level_step",1000))+1});
  }catch(e){return NextResponse.json({error:e.message},{status:400})}
}
