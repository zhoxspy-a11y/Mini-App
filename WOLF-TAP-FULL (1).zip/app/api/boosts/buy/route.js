import { NextResponse } from "next/server";
import { adminDb } from "@/lib/supabase";
import { requireTelegram } from "@/lib/auth";

export async function POST(req){
  try{
    const {user}=requireTelegram(req); const {boostId}=await req.json(); const db=adminDb();
    const {data:p}=await db.from("profiles").select("*").eq("telegram_id",user.id).single();
    const {data:b}=await db.from("balances").select("*").eq("profile_id",p.id).single();
    const {data:boost}=await db.from("boosts").select("*").eq("id",boostId).eq("active",true).single();
    if(!boost)throw new Error("Boost not found");
    if(b.coins<boost.price)throw new Error("Not enough WOLF");
    await db.from("balances").update({coins:b.coins-boost.price,updated_at:new Date().toISOString()}).eq("profile_id",p.id);
    await db.from("user_boosts").upsert({profile_id:p.id,boost_id:boost.id,level:1});
    await db.from("transactions").insert({profile_id:p.id,type:"boost",amount:-boost.price,metadata:{boost_id:boost.id}});
    return NextResponse.json({coins:b.coins-boost.price});
  }catch(e){return NextResponse.json({error:e.message},{status:400})}
}
