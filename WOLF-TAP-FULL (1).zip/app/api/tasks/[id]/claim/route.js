import { NextResponse } from "next/server";
import { adminDb } from "@/lib/supabase";
import { requireTelegram } from "@/lib/auth";
import { verifyTelegramMembership } from "@/lib/telegram";

export async function POST(req,{params}){
  try{
    const {user}=requireTelegram(req);
    const db=adminDb();
    const {data:p}=await db.from("profiles").select("*").eq("telegram_id",user.id).single();
    if(!p || p.suspended) throw new Error("Account unavailable");
    const {data:t}=await db.from("tasks").select("*").eq("id",params.id).eq("active",true).single();
    if(!t) throw new Error("Task not found");
    const {data:existing}=await db.from("task_claims").select("*").eq("task_id",t.id).eq("profile_id",p.id).maybeSingle();
    if(existing) return NextResponse.json({status:existing.status,coins:(await db.from("balances").select("coins").eq("profile_id",p.id).single()).data.coins});
    if(t.type==="telegram" && t.verification_value){
      const ok=await verifyTelegramMembership(t.verification_value,user.id);
      if(!ok) throw new Error("Join the Telegram channel first, then check again.");
    }
    if(t.require_manual_review || t.type==="youtube" || t.type==="link"){
      await db.from("task_claims").insert({task_id:t.id,profile_id:p.id,status:"pending",reward:t.reward});
      return NextResponse.json({status:"pending",coins:(await db.from("balances").select("coins").eq("profile_id",p.id).single()).data.coins});
    }
    const {data:b}=await db.from("balances").select("coins,lifetime_coins").eq("profile_id",p.id).single();
    await db.from("balances").update({coins:b.coins+t.reward,lifetime_coins:b.lifetime_coins+t.reward,updated_at:new Date().toISOString()}).eq("profile_id",p.id);
    await db.from("task_claims").insert({task_id:t.id,profile_id:p.id,status:"approved",reward:t.reward});
    await db.from("transactions").insert({profile_id:p.id,type:"task",amount:t.reward,metadata:{task_id:t.id}});
    return NextResponse.json({status:"approved",coins:b.coins+t.reward});
  }catch(e){return NextResponse.json({error:e.message},{status:400})}
}
