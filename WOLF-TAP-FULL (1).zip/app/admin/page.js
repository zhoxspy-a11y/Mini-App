"use client";
import { useEffect, useState } from "react";
import { Shield, ListChecks, Users, Plus, Trash2, Save } from "lucide-react";

export default function AdminPage(){
  const [initData,setInitData]=useState("");
  const [data,setData]=useState(null);
  const [form,setForm]=useState({type:"telegram",title:"",description:"",url:"",verification_value:"",reward:500,active:true,require_manual_review:false});
  const [error,setError]=useState("");

  useEffect(()=>{
    const tg=window.Telegram?.WebApp;
    if(!tg){setError("Open admin inside Telegram Mini App.");return}
    tg.ready(); setInitData(tg.initData||"");
    if(!tg.initData){setError("Telegram authentication data missing.");return}
    fetch("/api/admin/overview",{headers:{"x-telegram-init-data":tg.initData}})
      .then(r=>r.json()).then(j=>{if(j.error)throw Error(j.error);setData(j)}).catch(e=>setError(e.message));
  },[]);

  async function api(path,opts={}){
    const r=await fetch(path,{...opts,headers:{"content-type":"application/json","x-telegram-init-data":initData,...(opts.headers||{})}});
    const j=await r.json(); if(!r.ok)throw Error(j.error||"Request failed"); return j;
  }
  async function create(){
    try{
      const j=await api("/api/admin/tasks",{method:"POST",body:JSON.stringify(form)});
      setData(d=>({...d,tasks:[j.task,...d.tasks]}));
      setForm({type:"telegram",title:"",description:"",url:"",verification_value:"",reward:500,active:true,require_manual_review:false});
    }catch(e){setError(e.message)}
  }
  async function remove(id){
    try{await api(`/api/admin/tasks/${id}`,{method:"DELETE"});setData(d=>({...d,tasks:d.tasks.filter(t=>t.id!==id)}))}
    catch(e){setError(e.message)}
  }

  if(error)return <main className="admin-gate"><Shield size={36}/><h1>Admin</h1><p>{error}</p></main>;
  if(!data)return <main className="admin-gate"><p>Loading secure admin panel…</p></main>;

  return <main className="admin-wrap">
    <header className="admin-top"><div><span>WOLF TAP</span><h1>Admin Control</h1></div><div className="admin-badge"><Shield size={15}/> ADMIN</div></header>
    <section className="admin-stats">
      <div><small>USERS</small><b>{data.stats.users}</b></div>
      <div><small>COINS</small><b>{data.stats.coins.toLocaleString()}</b></div>
      <div><small>TASKS</small><b>{data.tasks.length}</b></div>
    </section>
    <section className="panel">
      <div className="panel-head"><b><Plus size={17}/> Create Task</b></div>
      <div className="form-grid">
        <select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option value="telegram">Telegram Channel</option><option value="youtube">YouTube</option><option value="link">Other Link</option></select>
        <input placeholder="Title" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/>
        <input placeholder="URL" value={form.url} onChange={e=>setForm({...form,url:e.target.value})}/>
        <input placeholder="Telegram @channel or chat ID" value={form.verification_value} onChange={e=>setForm({...form,verification_value:e.target.value})}/>
        <input type="number" placeholder="Reward" value={form.reward} onChange={e=>setForm({...form,reward:e.target.value})}/>
        <label><input type="checkbox" checked={form.require_manual_review} onChange={e=>setForm({...form,require_manual_review:e.target.checked})}/> Manual review</label>
        <button className="save" onClick={create}><Save size={17}/> Create Task</button>
      </div>
    </section>
    <section className="panel">
      <div className="panel-head"><b><ListChecks size={17}/> Task Manager</b></div>
      {data.tasks.map(t=><div className="admin-row" key={t.id}><div><b>{t.title}</b><small>{t.type} · +{t.reward} · {t.active?"Active":"Disabled"}</small></div><button onClick={()=>remove(t.id)}><Trash2 size={16}/></button></div>)}
    </section>
    <section className="panel"><div className="panel-head"><b><Users size={17}/> Recent Users</b></div>{data.users.map(u=><div className="admin-row" key={u.telegram_id}><div><b>{u.first_name||u.username||u.telegram_id}</b><small>#{u.telegram_id} · Level {u.level}</small></div><span>{u.coins.toLocaleString()} WOLF</span></div>)}</section>
  </main>;
}
