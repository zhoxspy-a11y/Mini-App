"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Home, ListChecks, Zap, Users, WalletCards, Copy, Check, ShieldCheck,
  ChevronRight, Settings2, LogOut, UserRound
} from "lucide-react";

const initial = {
  profile: null,
  coins: 0,
  energy: 0,
  maxEnergy: 1000,
  level: 1,
  tasks: [],
  boosts: []
};

export default function WolfTap() {
  const [data,setData] = useState(initial);
  const [tab,setTab] = useState("home");
  const [floats,setFloats] = useState([]);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  const [refCopied,setRefCopied] = useState(false);
  const [initData,setInitData] = useState("");

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (!tg) {
      setError("Open WOLF TAP inside Telegram Mini App.");
      return;
    }
    tg.ready();
    tg.expand();
    setInitData(tg.initData || "");
    if (!tg.initData) {
      setError("Telegram authentication data is missing.");
      return;
    }
    load(tg.initData);
  }, []);

  async function api(path, options={}) {
    const res = await fetch(path, {
      ...options,
      headers: {
        "content-type":"application/json",
        "x-telegram-init-data": initData,
        ...(options.headers || {})
      }
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || "Request failed");
    return json;
  }

  async function load(raw=initData) {
    try {
      const res = await fetch("/api/me", {headers:{"x-telegram-init-data":raw}});
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Could not load account");
      setData(json);
      setError("");
    } catch(e) { setError(e.message); }
  }

  async function tap(e) {
    if (busy || data.energy <= 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const nonce = crypto.randomUUID();
    setBusy(true);
    try {
      const json = await api("/api/game/tap", {
        method:"POST",
        body:JSON.stringify({tapCount:1,clientNonce:nonce})
      });
      setData(d=>({...d,...json}));
      const id=nonce;
      setFloats(f=>[...f,{id,x:e.clientX-rect.left,y:e.clientY-rect.top}]);
      setTimeout(()=>setFloats(f=>f.filter(x=>x.id!==id)),650);
      window.Telegram?.WebApp?.HapticFeedback?.impactOccurred?.("light");
    } catch(e) { setError(e.message); }
    finally { setBusy(false); }
  }

  async function claim(task) {
    try {
      const json = await api(`/api/tasks/${task.id}/claim`, {
        method:"POST",
        body:JSON.stringify({})
      });
      setData(d=>({...d,coins:json.coins,tasks:d.tasks.map(t=>t.id===task.id?{...t,claimStatus:json.status}:t)}));
      if (json.status === "approved") window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred?.("success");
    } catch(e) { setError(e.message); }
  }

  async function buyBoost(id) {
    try {
      const json=await api("/api/boosts/buy",{method:"POST",body:JSON.stringify({boostId:id})});
      setData(d=>({...d,...json}));
    } catch(e){setError(e.message)}
  }

  const referralLink = useMemo(()=>{
    const bot=process.env.NEXT_PUBLIC_BOT_USERNAME || "wolftapp_bot";
    const id=data.profile?.telegram_id || "";
    return `https://t.me/${bot}?startapp=ref_${id}`;
  },[data.profile]);

  function copyRef() {
    navigator.clipboard?.writeText(referralLink);
    setRefCopied(true); setTimeout(()=>setRefCopied(false),1200);
  }

  if (error && !data.profile) {
    return <main className="gate"><img src="/wolf.png" /><h1>WOLF TAP</h1><p>{error}</p><small>Configure the Telegram Mini App and open it from Telegram.</small></main>;
  }

  return (
    <main className="app">
      <div className="top">
        <div><span>WOLF TAP</span><h1>LEVEL {data.level}</h1></div>
        <div className="user-pill"><UserRound size={15}/>{data.profile?.first_name || "Wolf"}</div>
      </div>

      {error && <button className="error" onClick={()=>setError("")}>{error}</button>}

      {tab==="home" && <HomeScreen data={data} onTap={tap} floats={floats} setTab={setTab}/>}
      {tab==="tasks" && <Tasks tasks={data.tasks} claim={claim}/>}
      {tab==="boost" && <Boosts boosts={data.boosts} buyBoost={buyBoost}/>}
      {tab==="referral" && <Referral link={referralLink} copied={refCopied} copy={copyRef}/>}
      {tab==="wallet" && <Wallet coins={data.coins}/>}

      <nav className="nav">
        <Nav icon={<Home size={19}/>} text="Home" active={tab==="home"} click={()=>setTab("home")}/>
        <Nav icon={<ListChecks size={19}/>} text="Tasks" active={tab==="tasks"} click={()=>setTab("tasks")}/>
        <Nav icon={<Zap size={19}/>} text="Boost" active={tab==="boost"} click={()=>setTab("boost")}/>
        <Nav icon={<Users size={19}/>} text="Invite" active={tab==="referral"} click={()=>setTab("referral")}/>
        <Nav icon={<WalletCards size={19}/>} text="Wallet" active={tab==="wallet"} click={()=>setTab("wallet")}/>
      </nav>
    </main>
  );
}

function HomeScreen({data,onTap,floats,setTab}) {
  const progress=Math.min(100,((data.coins%1000)/1000)*100);
  return <section className="screen">
    <div className="coin-box"><small>GAME COINS</small><strong>{Number(data.coins).toLocaleString()}</strong><div className="progress"><i style={{width:`${progress}%`}}/></div><span>{progress.toFixed(0)}% to next level</span></div>
    <div className="wolf-zone" onPointerDown={onTap}>
      <div className="ring"/>
      <img src="/wolf.png" className="wolf" draggable="false" />
      {floats.map(f=><b className="float" key={f.id} style={{left:f.x,top:f.y}}>+1</b>)}
    </div>
    <div className="energy-head"><span>ENERGY</span><b>{data.energy} / {data.maxEnergy}</b></div>
    <div className="energy"><i style={{width:`${data.maxEnergy?data.energy/data.maxEnergy*100:0}%`}}/></div>
    <div className="cards">
      <button onClick={()=>setTab("tasks")}><ListChecks size={20}/><span>Tasks</span><b>Earn WOLF</b></button>
      <button onClick={()=>setTab("boost")}><Zap size={20}/><span>Boost</span><b>Increase power</b></button>
    </div>
  </section>;
}
function Tasks({tasks,claim}) {
  return <section className="screen"><Header title="Tasks" sub="Complete verified missions to earn WOLF."/>
    <div className="list">{tasks.length===0?<Empty text="No active tasks right now."/>:tasks.map(t=><div className="row" key={t.id}>
      <div className="row-icon"><ShieldCheck size={20}/></div><div className="row-main"><b>{t.title}</b><small>{t.type.toUpperCase()} · +{t.reward} WOLF</small></div>
      <button disabled={t.claimStatus==="approved" || t.claimStatus==="pending"} onClick={()=>claim(t)}>
        {t.claimStatus==="approved"?<Check size={18}/>:t.claimStatus==="pending"?"...":<ChevronRight size={18}/>}
      </button>
    </div>)}</div>
  </section>;
}
function Boosts({boosts,buyBoost}) {
  return <section className="screen"><Header title="Boost" sub="Permanent upgrades for your tap power."/>
    <div className="list">{boosts.map(b=><div className="row" key={b.id}><div className="row-icon"><Zap size={20}/></div><div className="row-main"><b>{b.name}</b><small>{b.description}</small></div><button className="price" onClick={()=>buyBoost(b.id)}>{b.price.toLocaleString()}</button></div>)}</div>
  </section>;
}
function Referral({link,copied,copy}) {
  return <section className="screen"><Header title="Invite" sub="Share your referral link and earn bonus WOLF."/>
    <div className="invite"><Users size={32}/><h3>Invite Friends</h3><p>Your referral reward is configured by the admin.</p></div>
    <div className="ref"><span>{link}</span><button onClick={copy}>{copied?<Check size={18}/>:<Copy size={18}/>}</button></div>
  </section>;
}
function Wallet({coins}) {
  return <section className="screen"><Header title="Wallet" sub="Your WOLF Game Coin balance."/>
    <div className="wallet"><small>GAME COINS</small><strong>{Number(coins).toLocaleString()}</strong><span>Reserved for the game / airdrop ecosystem.</span></div>
    <div className="notice"><ShieldCheck size={18}/><span>No ads and no cash withdrawal system is enabled.</span></div>
  </section>;
}
function Header({title,sub}){return <div className="header"><span>WOLF TAP</span><h2>{title}</h2><p>{sub}</p></div>}
function Empty({text}){return <div className="empty">{text}</div>}
function Nav({icon,text,active,click}){return <button className={active?"nav-item active":"nav-item"} onClick={click}>{icon}<span>{text}</span></button>}
