import WolfTap from "./wolf-tap";
export default function Page() {
  return <WolfTap />;
}
