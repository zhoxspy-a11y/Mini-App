import "./globals.css";

export const metadata = {
  title: "WOLF TAP",
  description: "Wolf Tap Telegram Mini App"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
